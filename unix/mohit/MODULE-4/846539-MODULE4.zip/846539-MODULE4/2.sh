userid	:user6
password:user6

path:cd /home


******************************************
*File name  :2.sh
*Author     :Venkat-846539
*Description:Commands 
*Date       :07/12/2012
******************************************
------------------------------------
PATH :[user6@NDAUnix exam]$ pwd

/home/user6/exam
------------------------------------

#START
------------------------------------
1)
------------------------------------
#!/bin/bash/

echo "Enter your choice"
read choice1
        if [ 1 -eq $choice1 ]
        then
                  echo -e "\n~~~~~~~~SEARCH -OPERATION ~~~~~~~"
                  echo "Enter the  File Name"
                  read file
                  echo "Enter the Word to Search"
                  read word

                if [ -f "$file" ]
                then
                        echo "You Entered  File Is exit"

                       awk -v wo=$word -F" " '
                       {
                        if($4==wo)
                                print $0
                       }' $file
                else
                        echo "File does not exit no more...!!"
                fi

        elif [ 2 -eq $choice1 ]
        then
                echo "Enter Old name of file "
                read old
                echo "Enter new name of file "
                read new


                echo "Before moving...!"
                ls
                mv $old $new
                echo "After...!"
                ls


        elif [ 3 -eq $choice1 ]
        then
                echo "Enter the file name "
                read file

                rm $file
                ls
        else
                echo "INvalid Choice..!!"

        fi


echo "Do you want Continue with process [y/n]?....!"
read ch
done
------------------------------------------------------
output:
------------------------------------

******MOVIE DETAILS********
---------------------------------
1.SEARCH
2.MOVE
3.DELETE
4.EXIT
----------------------------------
Enter your choice
1

~~~~~~~~SEARCH -OPERATION ~~~~~~~
Enter the  File Name
emp
Enter the Word to Search
Chennai
You Entered  File Is exit
Ven  846539  C    Chennai
Do you want Continue with process [y/n]?....!
y

******MOVIE DETAILS********
---------------------------------
1.SEARCH
2.MOVE
3.DELETE
4.EXIT
----------------------------------
Enter your choice
2
Enter Old name of file
emp1
Enter new name of file
new
Before moving...!
1.sh  3.sh  abc.txt  emp1          pqr.txt    ven   ven2
2.sh  4.sh  emp      file_err.lst  third.txt  ven1  ven3
After...!
1.sh  3.sh  abc.txt  file_err.lst  pqr.txt    ven   ven2
2.sh  4.sh  emp      new           third.txt  ven1  ven3
Do you want Continue with process [y/n]?....!
y

******MOVIE DETAILS********
---------------------------------
1.SEARCH
2.MOVE
3.DELETE
4.EXIT
----------------------------------
Enter your choice
3
Enter the file name
new
1.sh  2.sh  3.sh  4.sh  abc.txt  emp  file_err.lst  pqr.txt  third.txt  ven  ven1  ven2  ven3
Do you want Continue with process [y/n]?....!
n
[user6@NDAUnix exam]$ vi 2.sh
------------------------------------



------------------------------------
2)
------------------------------------
#!/bin/bash/

echo "Enter the file name"
read file

awk -F" " '
BEGIN{
        print"Display And Storing all odd lines and even lines"
}\
{
        count
        if(count%2==0)
        {
                print $0
                print $0 >>"even"

        }
        else
        {
                print $0
                print $0 >>"odd"
        }
        count+=1
}\
END{
        print "Byee..!"
}
' $file
------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ sh 2.2.sh
Enter the file name
emp
Display And Storing all odd lines and even lines
Ven  846539  C    Chennai
Ven  846539  C    Chenna
Ven  846539  C    mumbai
Ben  846538  C++  Banglore
Ben  846538  C++  Pune
Gwen 846537  Unix KADAPA
Gwen 846537  Unix DELHI
Gwen 846537  Unix Hydrabad
Gwen 846537  Unix Hydrabab

Byee..!
[user6@NDAUnix exam]$ cat odd
Ven  846539  C    Chenna
Ben  846538  C++  Banglore
Gwen 846537  Unix KADAPA
Gwen 846537  Unix Hydrabad

[user6@NDAUnix exam]$ cat even
Ven  846539  C    Chennai
Ven  846539  C    mumbai
Ben  846538  C++  Pune
Gwen 846537  Unix DELHI
Gwen 846537  Unix Hydrabab
------------------------------------

------------------------------------
3)
------------------------------------
#!/bin/bash

echo "Enter the path "
read path


ls $path

ls $path|grep ".txt"  | awk '
BEGIN{
}\
{
                count+=1
}
END{
        printf "count -%d\n",count
}'
------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ sh 2.3.sh
Enter the path
/home/user6

abc  data  exam  file1.txt  file2.txt  file3.txt  ven  ven1

count -3
------------------------------------
#END