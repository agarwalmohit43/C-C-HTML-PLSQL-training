userid	:user6
password:user6

path:cd /home


******************************************
*File name  :3.sh
*Author     :Venkat-846539
*Description:Commands 
*Date       :07/12/2012
******************************************
------------------------------------
PATH :[user6@NDAUnix exam]$ pwd

/home/user6/exam
------------------------------------
#START
------------------------------------
1)
------------------------------------
#!/bin/bash

echo "Enter the file"
read file
echo "Enter the new file name"
read new

if [ -f "$file" ]
then
        echo "You Entered  File Is exit"
        if [ -x "$file" ]
        then
                echo "You Entered  File have executable permission"
                mv $file $new

                ls
        else
                echo "Doesn't have executable permission"
        fi

        if [ -r "$new" ]
        then
                echo "You Entered  File have Readable permission"
 rm $new
                ls
        else
                echo "Doesn't have Readable permission"
        fi
fi




------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ cp emp data
[user6@NDAUnix exam]$ chmod 777 data
[user6@NDAUnix exam]$ sh 3.sh
Enter the file
data
Enter the new file name
new
You Entered  File Is exit
You Entered  File have executable permission
1.sh    2.3.sh  3.sh  abc.txt  even          new  pqr.txt    ven   ven2
2.2.sh  2.sh    4.sh  emp      file_err.lst  odd  third.txt  ven1  ven3
You Entered  File have Readable permission
1.sh    2.3.sh  3.sh  abc.txt  even          odd      third.txt  ven1  ven3
2.2.sh  2.sh    4.sh  emp      file_err.lst  pqr.txt  ven        ven2
------------------------------------


------------------------------------
2)
------------------------------------
#!/bin/bash

echo "Enter the file"
read file

awk '
BEGIN{
        print "Displaying the 5th characters"
}\
{
        name=$0;
        print name
        for(i=0;name[i]!='\0';i++)
        {
               if(i==5)
                       printf "5th - %c",name[i]
       }
}\
END{
        print "Displayed 5th character succuseefully...!"
}' $file


[or]

--------------------------------------------------------
#!/bin/bash
echo "Enter the file"
read file

cut -c5 $file

------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ cat data1
welcome to Capgemini
allis well
howare u
sooooo smart


[user6@NDAUnix exam]$ sh 3.2.sh
enter the file name
dat1
Displaying the 5th characters
o
s
r
o
Displayed 5th character succuseefully...!
---------------------------------------
#END