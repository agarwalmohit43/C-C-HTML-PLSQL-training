userid	:user6
password:user6

path:cd /home


******************************************
*File name  :1.sh
*Author     :Venkat-846539
*Description:Commands 
*Date       :07/12/2012
******************************************

------------------------------------
PATH :[user6@NDAUnix exam]$ pwd

/home/user6/exam
------------------------------------

------------------------------------
Table: emp
------------------------------------
[user6@NDAUnix exam]$ cat emp
Ven  846539  C    Chennai
Ven  846539  C    Chenna
Ven  846539  C    mumbai
Ben  846538  C++  Banglore
Ben  846538  C++  Pune
Gwen 846537  Unix KADAPA
Gwen 846537  Unix DELHI
Gwen 846537  Unix Hydrabad
Gwen 846537  Unix Hydrabab
------------------------------------

#START
------------------------------------
1.1)
------------------------------------
 sed -n -e '/a$/p' -e '/ab$/p'   emp

------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ sh 1.sh

Ven  846539  C    Chenna
Gwen 846537  Unix Hydrabab
------------------------------------



------------------------------------
1.2)
------------------------------------
awk -F" " '
{
        count++;
        if(count==4)
        {
            print $0
        }
}
' emp

------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ sh 1.sh

Ben  846538  C++  Banglore
------------------------------------



-----------------------------------------------------
1.3)
-------------------------------------------------------

paste -d" " abc.txt pqr.txt >third.txt 2>file_err.lst
-----------------------------------------------------------------------
output:
------------------------------------------------------------------------
[user6@NDAUnix exam]$ cat abc.txt
hi
welcome

[user6@NDAUnix exam]$ cat pqr.txt
ven
Capgemini

[user6@NDAUnix exam]$ paste -d" " abc.txt pqr.txt >third.txt 2>file_err.lst
[user6@NDAUnix exam]$ cat third.txt
hi ven
welcome  Capgemini
------------------------------------------------------------------------------


----------------------------------------------------
1.4)
-----------------------------------------------------
ls -l |grep -i -w "x"
------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ ls -l
total 36
-rw-rw-r-- 1 user6 user6  341 Jul 12 09:56 1.sh
-rw-rw-r-- 1 user6 user6    0 Jul 12 08:38 2.sh
drwxrwxr-x 2 user6 user6 4096 Jul 12 09:42 ven
drwxrwxr-- 2 user6 user6 4096 Jul 12 09:42 ven1
drwxrwxr-x 2 user6 user6 4096 Jul 12 09:43 ven2
drwxrwxr-- 2 user6 user6 4096 Jul 12 09:43 ven3

Result:
[user6@NDAUnix exam]$ ls -l |grep -i -w "x"
drwxrwxr-x 2 user6 user6 4096 Jul 12 09:42 ven
drwxrwxr-x 2 user6 user6 4096 Jul 12 09:43 ven2
------------------------------------
OR
------------------------------------
1.4)Shell_script
#!/bin/bash
echo "List of all the Directories in current Directory"
echo "Which Others have execute permission"

for file in *
do
        if [  -x "$file" ]
        then
                echo "$file- file have Executable permmiion"
        fi

done
------------------------------------



------------------------------------
1.5)
------------------------------------
date "+%m-%d-%Y"
------------------------------------
output:
------------------------------------
[user6@NDAUnix exam]$ date "+%m-%d-%Y"
07-12-2016
------------------------------------
#END

